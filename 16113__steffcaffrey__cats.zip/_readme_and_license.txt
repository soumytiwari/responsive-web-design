Sound pack downloaded from Freesound
----------------------------------------

"Cats"

This pack of sounds contains sounds by the following user:
 - steffcaffrey ( https://freesound.org/people/steffcaffrey/ )

You can find this pack online at: https://freesound.org/people/steffcaffrey/packs/16113/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 479272__steffcaffrey__new-cat-meow-1.wav
    * url: https://freesound.org/s/479272/
    * license: Creative Commons 0
  * 479271__steffcaffrey__new-cat-meow-2.wav
    * url: https://freesound.org/s/479271/
    * license: Creative Commons 0
  * 415107__steffcaffrey__catwhirr.wav
    * url: https://freesound.org/s/415107/
    * license: Creative Commons 0
  * 415060__steffcaffrey__cateatbiscuit.wav
    * url: https://freesound.org/s/415060/
    * license: Creative Commons 0
  * 262314__steffcaffrey__cat-meow3.wav
    * url: https://freesound.org/s/262314/
    * license: Creative Commons 0
  * 262313__steffcaffrey__cat-meow2.wav
    * url: https://freesound.org/s/262313/
    * license: Creative Commons 0
  * 262312__steffcaffrey__cat-meow1.wav
    * url: https://freesound.org/s/262312/
    * license: Creative Commons 0
  * 262311__steffcaffrey__twit6.wav
    * url: https://freesound.org/s/262311/
    * license: Creative Commons 0
  * 262310__steffcaffrey__twit5.wav
    * url: https://freesound.org/s/262310/
    * license: Creative Commons 0
  * 262309__steffcaffrey__twit4.wav
    * url: https://freesound.org/s/262309/
    * license: Creative Commons 0
  * 262308__steffcaffrey__twit3.wav
    * url: https://freesound.org/s/262308/
    * license: Creative Commons 0
  * 262307__steffcaffrey__twitter2.wav
    * url: https://freesound.org/s/262307/
    * license: Creative Commons 0
  * 262306__steffcaffrey__cat-twit1.wav
    * url: https://freesound.org/s/262306/
    * license: Creative Commons 0


